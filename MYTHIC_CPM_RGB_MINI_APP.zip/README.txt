MYTHIC.CPM RGB PAYMENT MINI APP — PREVIEW ONLY

Contents:
- index.html: Animated RGB responsive Telegram Mini App landing page
- mythic_banner.png: Static banner for website
- MYTHIC_CPM_RGB_LOOP.gif: Animated rainbow lighting banner for Telegram

No payments or automatic access activation are enabled. All package buttons show a locked notice.

To publish: upload index.html and mythic_banner.png to a HTTPS static website (such as GitHub Pages). Then ask your developer to connect that HTTPS URL as the Telegram Mini App / Web App button in @MYTHIC666_PAYMENT_BOT. The current Python bot remains unchanged.

To use the GIF: upload MYTHIC_CPM_RGB_LOOP.gif as an animation in Telegram; a developer can use send_animation() to show it in /start. Telegram may compress/re-encode the file.

Do not publish payment credentials in HTML. Server-side verification and an activation integration are required before enabling payments.
